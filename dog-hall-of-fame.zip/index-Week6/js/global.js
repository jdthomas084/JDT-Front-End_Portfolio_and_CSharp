const images = document.querySelectorAll(".img-click");
const reset_button = document.querySelector(".paw");
//
const hero = document.getElementById("heroImg");
const textElem = document.getElementById("announcement");

// Update hero image + text
const setHeroDog = (img) => {
  hero.src = img.src;
  hero.alt = img.alt;
  textElem.textContent = img.alt;
};

// Reset to defaults
const resetHero = () => {
  hero.src = "/img/paw_print.png";
  hero.alt = "Featured Canine";
  textElem.textContent = "Featured Canine";
};

// Attach click handlers to all thumbnails
images.forEach(img => {
  img.addEventListener("click", () => {
    setHeroDog(img);
  });
});

// Paw print Reset button
reset_button.addEventListener("click", () => {resetHero()})