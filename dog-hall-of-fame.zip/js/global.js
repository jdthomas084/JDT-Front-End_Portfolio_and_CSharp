const images = document.querySelectorAll(".img-click");
//
// Set the initial hero image and text on page load
set_Hero_Dog('img0');  //will default to first image on page load

images.forEach(img => { //loops through all images with the class of img-click
  img.addEventListener('click', (e) => { //adds an event to each of them
    const elem = document.getElementById('right');// Target the Right Container
    elem.innerHTML = "";// Clear out the HTML in the Right Container
    set_Hero_Dog(e.target.id); //sends their unique ID 
  })
});

function set_Hero_Dog(imgId) {
  // Get the hero image and text elements
  const hero = document.getElementById('heroImg');
  const textElem = document.getElementById('announcement');
  const img = document.getElementById(imgId);

  // Update the hero image and text based on the clicked thumbnail
  hero.src = img.src;
  hero.alt = img.alt;
  textElem.textContent = img.alt;

  const name = img.alt.split(',')[0];
}