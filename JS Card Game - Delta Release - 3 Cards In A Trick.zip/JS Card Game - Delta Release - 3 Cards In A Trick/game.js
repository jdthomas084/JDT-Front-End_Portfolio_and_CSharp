const RANKS = ["ACE", "DEUCE", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "JACK", "QUEEN", "KING"];
const SUITS = ["CLUBS", "HEARTS", "DIAMONDS", "SPADES", "ORBS", "STARS", "ARCS", "SWORDS", "FOOLS", "ROYALS", "EAGLES", "NAVIES", "JOKERS"];


class Card {
    constructor(r, s) {
        this.r = r;
        this.s = s;
    }
    get rank_str() { return RANKS[this.r]; }
    get suit_str() { return SUITS[this.s]; }
}

// Internal deck (never exposed directly)
let deck = [];

// Build full deck once
function buildDeck() {
    deck = [];
    for (let r = 0; r < RANKS.length; r++) {
        for (let s = 0; s < SUITS.length; s++) {
            deck.push(new Card(r, s));
        }
    }
}

// Fisher–Yates shuffle (optimal)
function shuffleDeck() {
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
}

// Deal one card from the top
function dealOne() {
    return deck.length ? deck.pop() : null;
}

// Reset + shuffle
function resetDeck() {
    buildDeck();
    shuffleDeck();
}

// Initialize once at load
resetDeck();

const CardEngine = {
    dealOne,
    resetDeck,
    remaining: () => deck.length
};

function dealAll(hand) {
    // Find ALL <ul> elements whose id ends with "_Cards"
    const lists = hand.querySelectorAll('ul[id$="_Cards"]');

    lists.forEach(list => {
        list.querySelectorAll('li').forEach(slot => {
            if(slot.classList.contains("disabled")){enableSlot(slot);}
            const c = CardEngine.dealOne();
            slot.textContent = c
                ? `${c.rank_str} OF ${c.suit_str}`
                : "No cards left";
        });
    });
}


const btn_PlaceCard_P1 = document.getElementById("btn_PlaceCard_P1");
const btn_PlaceCard_P2 = document.getElementById("btn_PlaceCard_P2");
const evaluate_Btn = document.getElementById("btn_Evaluate");
let draggedText = null;

// Make source items draggable
document.querySelectorAll('#p3_Cards li').forEach(item => {
    item.addEventListener("dragstart", e => {
        draggedEl = item;                       // remember the element
        draggedText = item.textContent.trim();  // remember its text
        e.dataTransfer.effectAllowed = "move";
    });
});

// Allow dropping into destination items
document.querySelectorAll('#trick li').forEach(target => {
    target.addEventListener("dragover", e => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
    });

    target.addEventListener("drop", () => {
        if (draggedText) {
            target.textContent = draggedText;

            // Replace source text with placeholder instead of blank
            draggedEl.textContent = "---";

            // Disable the source element
            draggedEl.classList.add("disabled");

            draggedText = null;
            draggedEl = null;
        }
    });
});

function enableSlot(el) {
    el.classList.remove("disabled");
}

evaluate_Btn.addEventListener('click', () => {
    const arr_Trick = document.querySelectorAll('#trick li');
    let slot_is_Empty = false;

    // Check for empty slots
    arr_Trick.forEach(list_item => {
        const text = list_item.textContent.trim();

        if(list_item.textContent.trim() === "")
        {
            slot_is_Empty = true;
        }
        else {
            slot_is_Empty = false;
        }
    });

    if(slot_is_Empty === true)
    {
        alert("Must Have Three Cards In Place To Evaluate This Trick!");
    }
});

// Programmer-defined Event Listeners to 'place a random Card into the Trick' from a Computer Hand.
btn_PlaceCard_P1.addEventListener('click', () => {
    const cards_P1 = document.querySelectorAll('#p1_Cards li');
    let arr_len = cards_P1.length;
    let idx = Math.floor(Math.random() * arr_len);

    const trickCard1 = document.getElementById("trickCard_1");
    const randomCard = cards_P1[idx];

    trickCard1.innerHTML = randomCard.textContent;

    // Below lines to delete the current Card from the Player Hand
    const elem_ID = document.getElementById(cards_P1[idx].id);
    elem_ID.innerHTML = '';
});

btn_PlaceCard_P2.addEventListener('click', () => {
    const cards_P2 = document.querySelectorAll('#p2_Cards li');
    let arr_len = cards_P2.length;
    let idx = Math.floor(Math.random() * arr_len);

    const trickCard2 = document.getElementById("trickCard_2");
    const randomCard = cards_P2[idx];

    trickCard2.innerHTML = randomCard.textContent;

    // Below lines to delete the current Card from the Player Hand
    const elem_ID = document.getElementById(cards_P2[idx].id);
    elem_ID.innerHTML = '';
});
