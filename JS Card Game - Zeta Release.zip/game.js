const RANKS = ["ACE", "DEUCE", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "JACK", "QUEEN", "KING"];
const SUITS = ["CLUBS", "HEARTS", "DIAMONDS", "SPADES", "ORBS", "STARS", "ARCS", "SWORDS", "FOOLS", "ROYALS", "EAGLES", "NAVIES", "JOKERS"];


class Card {
    constructor(r, s) {
        this.r = r;
        this.s = s;
    }
    get rank_str() { return RANKS[this.r]; }
    get suit_str() { return SUITS[this.s]; }
}

// Internal deck (never exposed directly)
let deck = [];

// Build full deck once
function buildDeck() {
    deck = [];
    for (let r = 0; r < RANKS.length; r++) {
        for (let s = 0; s < SUITS.length; s++) {
            deck.push(new Card(r, s));
        }
    }
}

// Fisher–Yates shuffle (optimal)
function shuffleDeck() {
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
}

// Deal one card from the top
function dealOne() {
    return deck.length ? deck.pop() : null;
}

// Reset + shuffle
function resetDeck() {
    buildDeck();
    shuffleDeck();
}

// Initialize once at load
resetDeck();

const CardEngine = {
    dealOne,
    resetDeck,
    remaining: () => deck.length
};

function dealAll(hand) {
    // Find ALL <ul> elements whose id ends with "_Cards"
    const lists = hand.querySelectorAll('ul[id$="_Cards"]');

    lists.forEach(list => {
        list.querySelectorAll('li').forEach(slot => {
            if (slot.classList.contains("disabled")) { enableSlot(slot); }
            const c = CardEngine.dealOne();
            slot.textContent = c
                ? `${c.rank_str} OF ${c.suit_str}`
                : "No cards left";
        });
    });
}

const evaluate_Btn = document.getElementById("btn_Evaluate");
let draggedText = null;

// Make source items draggable
document.querySelectorAll('#p3_Cards li').forEach(item => {
    item.addEventListener("dragstart", e => {
        draggedEl = item;                       // remember the element
        draggedText = item.textContent.trim();  // remember its text
        e.dataTransfer.effectAllowed = "move";
    });
});

// Allow dropping into destination items
document.querySelectorAll('#trick li').forEach(target => {
    target.addEventListener("dragover", e => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
    });

    target.addEventListener("drop", () => {
        if (draggedText) {
            target.textContent = draggedText;

            // Replace source text with placeholder instead of blank
            draggedEl.textContent = "---";

            // Disable the source element
            draggedEl.classList.add("disabled");

            draggedText = null;
            draggedEl = null;
        }
    });
});

function enableSlot(el) {
    el.classList.remove("disabled");
}

evaluate_Btn.addEventListener('click', () => {
    const arr_Trick = document.querySelectorAll('#trick li');
    const slot_is_Empty = Array.from(arr_Trick).some(li => li.textContent.trim() === "");

    if (slot_is_Empty) {
        alert("Must Have Three Cards In Place To Evaluate This Trick!");
    } else {
        alert("Evaluating Trick...");
        const { rank, suit } = evaluateTrick();
        alert(`Trick evaluated. Winner: ${rank} of ${suit}`);
    }
});

document.addEventListener('click', e => {
    if (!e.target.matches('#btn_PlaceCard_P1, #btn_PlaceCard_P2')) return;

    const isP1 = e.target.id === 'btn_PlaceCard_P1';
    const handSelector = isP1 ? '#p1_Cards li' : '#p2_Cards li';
    const trickSlot = document.getElementById(isP1 ? 'trickCard_1' : 'trickCard_2');

    const cards = document.querySelectorAll(handSelector);
    const idx = Math.floor(Math.random() * cards.length);
    const card = cards[idx];

    trickSlot.textContent = card.textContent;
    card.textContent = '';
});

// Programmer-defined function to Evaluate the Trick (compare the three Cards and determine the winner)
function evaluateTrick() {
    const trickCards = document.querySelectorAll('#trick li');

    const cardValues = Array.from(trickCards).map(card => {
        const text = card.textContent.trim();
        const [rank, , suit] = text.split(' ');

        return {
            rank,
            suit,
            rankValue: RANKS.indexOf(rank),
            suitValue: SUITS.indexOf(suit)
        };
    });

    // Sort highest → lowest
    cardValues.sort((a, b) => {
        if (a.rankValue === b.rankValue) {
            return b.suitValue - a.suitValue;
        }
        return b.rankValue - a.rankValue;
    });

    return cardValues[0]; // <-- WINNER
}
//